// Cloud24 Connect Main Script

document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const menuBtn = document.querySelector('.menu-btn'); // You need to add this to HTML if missing
    const navRight = document.querySelector('.nav-right');

    if (menuBtn) {
        menuBtn.addEventListener('click', () => {
            navRight.classList.toggle('active');
        });
    }

    // Close menu when a link is clicked
    document.querySelectorAll('.menu li a').forEach(link => {
        link.addEventListener('click', () => {
            if (navRight.classList.contains('active')) {
                navRight.classList.remove('active');
            }
        });
    });

    // Smooth Scroll for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId && targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Header Scroll Effect (Navbar background)
    const nav = document.querySelector('nav');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }

        // Update active menu item based on scroll position
        updateActiveMenuItem();
    });

    // Scroll Spy - Update active menu item
    function updateActiveMenuItem() {
        const sections = document.querySelectorAll('section[id], header[id]');
        const menuLinks = document.querySelectorAll('.menu li a');

        let currentSection = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;

            if (window.scrollY >= (sectionTop - 100)) {
                currentSection = section.getAttribute('id');
            }
        });

        menuLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
    }

    // Initial call to set active state on page load
    updateActiveMenuItem();


    // Chat Widget Toggle
    window.toggleChat = function () { // Expose to global scope for onclick in HTML
        const chat = document.getElementById('chatBox');
        if (chat) {
            chat.style.display = chat.style.display === 'flex' ? 'none' : 'flex';
        }
    }

    // Future 3D/Animation initialization will go here
    initParticles();

    // Scroll Animations (Intersection Observer)
    // Scroll Animations (Intersection Observer)
    const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');

                // Optional: Stagger children if it's a grid/container
                if (entry.target.classList.contains('grid') || entry.target.classList.contains('leadership-grid')) {
                    const children = entry.target.children;
                    Array.from(children).forEach((child, index) => {
                        child.style.transitionDelay = `${index * 150}ms`;
                        child.classList.add('active'); // Ensure children have something to animate if needed
                    });
                }

                // Stop observing once revealed
                observer.unobserve(entry.target);
            }
        });
    }, {
        root: null,
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    });

    revealElements.forEach(el => revealObserver.observe(el));

    // Auto-assign stagger classes to grids for initial load
    document.querySelectorAll('.grid > div, .leadership-grid > div').forEach((el, index) => {
        // Reset index for each parent? generic simple stagger for now
        // actually better handled by the observer above dynamically
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.8s cubic-bezier(0.2, 0.8, 0.2, 1)';
    });

    // Observer for grid items directly
    const itemObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Find index relative to parent for delay
                const siblings = Array.from(entry.target.parentNode.children);
                const index = siblings.indexOf(entry.target);

                setTimeout(() => {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, index * 100); // 100ms stagger

                itemObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.grid > div, .leadership-grid > div, .pricing-container > div').forEach(el => {
        itemObserver.observe(el);
    });

    // 3D Tilt Effect for Service Cards
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * -10; // Max 10deg rotation
            const rotateY = ((x - centerX) / centerX) * 10;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.05, 1.05, 1.05)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
        });
    });
});

// Pricing Toggle Logic
const toggle = document.querySelector('.switch input');
const priceElements = document.querySelectorAll('.price'); // Getting the price divs

if (toggle) {
    toggle.addEventListener('change', () => {
        // Add fade-out class
        priceElements.forEach(el => el.classList.add('fade-out'));

        // Wait for fade out, then change content and fade in
        setTimeout(() => {
            if (toggle.checked) {
                // Update to Yearly Prices
                document.querySelector('.toggle-label:last-child').classList.add('active');
                document.querySelector('.toggle-label:first-child').classList.remove('active');

                if (priceElements[0]) priceElements[0].innerHTML = '$190<span>/yr</span>';
                if (priceElements[1]) priceElements[1].innerHTML = '$790<span>/yr</span>';
                if (priceElements[2]) priceElements[2].innerHTML = '$390<span>/yr</span>';
            } else {
                // Back to Monthly
                document.querySelector('.toggle-label:last-child').classList.remove('active');
                document.querySelector('.toggle-label:first-child').classList.add('active');

                if (priceElements[0]) priceElements[0].innerHTML = '$19<span>/mo</span>';
                if (priceElements[1]) priceElements[1].innerHTML = '$79<span>/mo</span>';
                if (priceElements[2]) priceElements[2].innerHTML = '$39<span>/mo</span>';
            }

            // Remove fade-out (triggers fade-in)
            priceElements.forEach(el => el.classList.remove('fade-out'));
        }, 300); // Matches CSS transition time
    });
}

function initParticles() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let width, height;
    let particles = [];

    // Resize
    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // Particle Class
    class Particle {
        constructor() {
            this.x = Math.random() * width;
            this.y = Math.random() * height;
            this.vx = (Math.random() - 0.5) * 0.5;
            this.vy = (Math.random() - 0.5) * 0.5;
            this.size = Math.random() * 2 + 1;
            this.color = `rgba(79, 107, 255, ${Math.random() * 0.3})`; // Light blue tint
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;

            if (this.x < 0) this.x = width;
            if (this.x > width) this.x = 0;
            if (this.y < 0) this.y = height;
            if (this.y > height) this.y = 0;
        }

        draw() {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    // Initialize Particles
    for (let i = 0; i < 50; i++) {
        particles.push(new Particle());
    }

    // Animation Loop
    function animate() {
        ctx.clearRect(0, 0, width, height);

        // Draw connections
        ctx.strokeStyle = 'rgba(79, 107, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 150) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                }
            }
        }

        particles.forEach(p => {
            p.update();
            p.draw();
        });

        requestAnimationFrame(animate);
    }
    animate();
}

// Domain Availability Mock
window.checkDomain = function () {
    const input = document.getElementById('domainInput');
    const resultDiv = document.getElementById('domainResult');
    const domain = input.value.trim();

    if (!domain) return;

    // Simulate API call
    resultDiv.innerHTML = '<span style="color:var(--text-muted);"><i class="fas fa-circle-notch fa-spin"></i> Checking availability...</span>';
    resultDiv.classList.add('show');

    setTimeout(() => {
        // Mock logic: lengths > 5 are available
        const isAvailable = domain.length > 5 && !domain.includes('google') && !domain.includes('facebook');

        if (isAvailable) {
            resultDiv.innerHTML = `<span class="domain-available"><i class="fas fa-check-circle"></i> <strong>${domain}</strong> is available! Start building now.</span>`;
        } else {
            resultDiv.innerHTML = `<span class="domain-taken"><i class="fas fa-times-circle"></i> <strong>${domain}</strong> is already taken. Try another?</span>`;
        }
    }, 1500);
}

// FAQ Accordion
document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
        const item = question.parentElement;
        const isActive = item.classList.contains('active');

        // Close all other items
        document.querySelectorAll('.faq-item').forEach(otherItem => {
            otherItem.classList.remove('active');
        });

        // Toggle current item
        if (!isActive) {
            item.classList.add('active');
        }
    });
});

